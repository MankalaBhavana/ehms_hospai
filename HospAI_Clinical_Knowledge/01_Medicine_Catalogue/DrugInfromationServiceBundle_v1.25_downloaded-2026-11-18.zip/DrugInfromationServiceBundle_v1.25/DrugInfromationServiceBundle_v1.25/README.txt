********************************************************
	What is DISB ?
********************************************************

Drug Information Service Bundle is a software providing a set of restful services to receive information about substances, generics, and branded medicines present in the Common Drug Codes for India released by National Resource Centre for EHR Standards (NRCeS) at Centre for Development of Advanced Computing (C-DAC), Pune.

The software can be useful in receiving additional reference / knowledge about the drugs in various usage scenarios.

Note: This Service is developed, build & tested on OpenJDK 17.


********************************************************
		DISB's Prerequisite
********************************************************

1. JRE/JDK 17 should be installed on machine

	Set the environment variables for Java.
	e.g : Setting the environment variables for Java considering OpenJDK 17 is intalled.  
		Windows: Add System Environment Variable: JAVA_HOME - C:\Program
        Files\ojdkbuild\java-17-openjdk-17.*
		LINUX: modify '/etc/profile': JAVA_HOME - export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64/

	Append the path value for JAVA in the PATH environment variable.
	e.g :  Windows: C:\Program Files\ojdkbuild\java-17-openjdk-17.*\bin
	       LINUX: modify '/etc/profile': export PATH=/usr/lib/jvm/java-17-openjdk-amd64/bin:$PATH


********************************************************
	DISB's Folder Structure.
********************************************************

Extracted zip contains following:
1. DISB-1.25.jar : DISB Server.
2. Data : Index containing all information related to concepts.
3. run.bat (For Windows), run.sh (For Unix)
4. README.txt and LICENSE.txt


********************************************************
	Configure and Deploy DISB
********************************************************
 
 1. Extract DrugInformationServiceBundle_v1.25.zip

Steps to run on Windows:
1) Open Command Line Terminal and go to directory where zip is extracted, you should see Folder structure as mentioned above.
2) run command : run.bat 
	By default DISB Server runs on port 9090
	To Change port number 
		run command : run.bat -p <portno> 
	    	e.g: run.bat -p 8085

Steps to run on Linux:
1)Open Terminal and go in directory where zip is extracted, you should see Folder structure as mentioned above.
2) run command : sh run.sh or ./run.sh
	By default DISB Server runs on port 9090
	To Change port number 
		run command : run.sh -p <portno> 
		e.g: sh run.sh -p 8085 or ./run.sh -p 8085

 2. Swagger api is provided to understand how to use DISB REST api
 		To access Swagger API :
 			open url : http://<hostname>:<portno>/swagger-ui.html
