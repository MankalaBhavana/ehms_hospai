 helpfunction()
{
    echo ""
    echo "Usage: $0 -p portno"
    echo -e "\t-p port on which server is to be run"
    echo -e "\t-h print help"
    exit 1
}

port=9090

while getopts ":p:h:" opt
do
   case "$opt" in
      p) port=$OPTARG ;;
      h) helpfunction ;;
      ?) helpfunction ;;
   esac
done

if ! [[ $port =~ ^[0-9]+$ ]]
    then
        echo "ERROR: Not a valid port" ;exit 1
fi

java -jar -Dserver.port=$port disb-1.25.jar
