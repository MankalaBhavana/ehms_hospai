@echo off

set p=9090

:getport
if "%1"=="" goto done
set arg=%1
if "%arg:~0,1%"=="-" (
   set argment=%arg:~1,250%
) else (
   set "%argment%=%1"
   set argment=
)
shift
goto getport
:done

java -jar -Dserver.port=%p% DISB-1.0.0.jar

